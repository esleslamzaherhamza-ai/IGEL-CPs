plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.islamhamza.photopeamobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.islamhamza.photopeamobile"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
    dependencies {
        implementation("androidx.activity:activity-ktx:1.9.3")
    }
}
